clear
python test_blockchain.py
